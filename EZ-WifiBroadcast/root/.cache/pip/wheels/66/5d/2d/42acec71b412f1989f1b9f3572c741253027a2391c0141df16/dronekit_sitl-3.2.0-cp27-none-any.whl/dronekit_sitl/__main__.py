#!/usr/bin/python

import sys
import re
from dronekit_sitl import main

main(sys.argv[1:])
